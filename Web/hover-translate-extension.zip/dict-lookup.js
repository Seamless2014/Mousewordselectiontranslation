/**
 * 词形还原 + 两级词库查询（共享模块）。
 *
 * 为什么单独抽一个文件：
 *   改造前这段逻辑在 content.js / test-extra.js / test-verify.js 里各存了一份副本，
 *   改一处要同步三处，极易漏改。service worker 支持 importScripts，
 *   所以把唯一实现放在这里，运行时由 background.js 加载，测试也直接加载同一份。
 *
 * 依赖（由调用方保证已先加载，顺序不得颠倒）：
 *   dict.js        -> var LOCAL_DICT
 *   dict-extra.js  -> var DICT_EXTRA
 *   dict-phrase.js -> var DICT_PHRASE（可选，缺失时词组查询自动降级）
 *
 * 本文件不持有词库引用，只在查询时按名读取，因此：
 *   - 词库缺失时降级返回 null，不抛错
 *   - 可在同一进程内被多个上下文复用（一个文件 = 一份函数定义）
 */
"use strict";

/**
 * 不规则词形表：变体 -> 唯一原形。
 * 表里没有的走规则还原（见 lemmatize）。
 */
var HT_IRREGULAR = {
  was: "be", were: "be", been: "be", is: "be", are: "be", am: "be",
  has: "have", had: "have", did: "do", does: "do", done: "do",
  went: "go", gone: "go", made: "make", took: "take", taken: "take",
  gave: "give", given: "give", found: "find", knew: "know", known: "know",
  thought: "think", saw: "see", seen: "see", wanted: "want",
  said: "say", told: "tell", became: "become", left: "leave",
  kept: "keep", began: "begin", begun: "begin", ran: "run",
  brought: "bring", wrote: "write", written: "write", stood: "stand",
  lost: "lose", paid: "pay", met: "meet", led: "lead",
  understood: "understand", spoke: "speak", spoken: "speak",
  read: "read", spent: "spend", grew: "grow", grown: "grow",
  won: "win", offered: "offer", built: "build", fell: "fall",
  cut: "cut", reached: "reach", remained: "remain",
  suggested: "suggest", raised: "raise", passed: "pass", sold: "sell",
  required: "require", reported: "report", decided: "decide",
  returned: "return", explained: "explain", developed: "develop",
  carried: "carry", broke: "break", broken: "break", received: "receive",
  agreed: "agree", produced: "produce", ate: "eat", eaten: "eat",
  covered: "cover", caught: "catch", drew: "draw", drawn: "draw",
  chose: "choose", chosen: "choose", caused: "cause",
  children: "child", men: "man", women: "woman", feet: "foot",
  teeth: "tooth", mice: "mouse", people: "people", lives: "life",
  better: "good", best: "good", worse: "bad", worst: "bad",
  more: "much", most: "much", less: "little", least: "little",
  data: "data", analyses: "analysis", indices: "index"
};

/**
 * 词形还原。
 *
 * 返回值有两种形态：
 *   - 命中不规则词表时返回 string（唯一原形，如 was -> "be"）
 *   - 否则返回候选词数组（按优先级排列），交由调用方逐个查词库
 *   - 无候选时返回 null
 */
function lemmatize(word) {
  const w = String(word).toLowerCase();
  if (Object.prototype.hasOwnProperty.call(HT_IRREGULAR, w)) return HT_IRREGULAR[w];
  if (w.length <= 3) return null;

  const c = [];
  // 复数 / 第三人称单数
  if (w.endsWith("ies")) c.push(w.slice(0, -3) + "y");
  if (w.endsWith("ves")) c.push(w.slice(0, -3) + "f", w.slice(0, -3) + "fe");
  if (w.endsWith("ses") || w.endsWith("xes") || w.endsWith("zes") ||
      w.endsWith("ches") || w.endsWith("shes")) c.push(w.slice(0, -2));
  if (w.endsWith("es")) c.push(w.slice(0, -1), w.slice(0, -2));
  if (w.endsWith("s") && !w.endsWith("ss")) c.push(w.slice(0, -1));
  // 进行时 / 动名词
  if (w.endsWith("ying")) c.push(w.slice(0, -4) + "ie", w.slice(0, -4) + "y");
  if (w.endsWith("ing")) {
    c.push(w.slice(0, -3), w.slice(0, -3) + "e");
    const stem = w.slice(0, -3);
    // 双写辅音：running -> run
    if (stem.length > 2 && stem[stem.length - 1] === stem[stem.length - 2]) c.push(stem.slice(0, -1));
  }
  // 过去式 / 过去分词
  if (w.endsWith("ied")) c.push(w.slice(0, -3) + "y");
  if (w.endsWith("ed")) {
    c.push(w.slice(0, -2), w.slice(0, -1));
    const stem = w.slice(0, -2);
    if (stem.length > 2 && stem[stem.length - 1] === stem[stem.length - 2]) c.push(stem.slice(0, -1));
  }
  // 比较级 / 最高级
  if (w.endsWith("ier")) c.push(w.slice(0, -3) + "y");
  if (w.endsWith("iest")) c.push(w.slice(0, -4) + "y");
  if (w.endsWith("er")) c.push(w.slice(0, -2), w.slice(0, -1));
  if (w.endsWith("est")) c.push(w.slice(0, -3), w.slice(0, -2));
  // 副词
  if (w.endsWith("ily")) c.push(w.slice(0, -3) + "y");
  if (w.endsWith("ly")) c.push(w.slice(0, -2), w.slice(0, -2) + "e");

  return c.length ? c : null;
}

/**
 * 在单个词库对象中查词。
 *
 * 用 hasOwnProperty 而非 `dict[key]` 直接取值：ECDICT 里确实收录了
 * constructor / tostring 这类"撞上 Object.prototype 属性名"的真实单词，
 * 直接取值会命中原型链上的函数，把 JS 内置方法当成词条返回。
 *
 * @param {object} dict 词库对象（LOCAL_DICT 或 DICT_EXTRA）
 * @param {string} key  小写单词
 * @returns {object|null} 命中则返回词条对象
 */
function lookupInDict(dict, key) {
  if (!dict || typeof dict !== "object") return null;
  if (!Object.prototype.hasOwnProperty.call(dict, key)) return null;
  const entry = dict[key];
  return entry && typeof entry === "object" ? entry : null;
}

/**
 * 连字符合成词拆词查询（v1.2.1）。
 *
 * 词库只收纯字母词，decision-maker / real-time / mother-in-law 这类合成词
 * 整词查不到，原实现会直接掉进在线兜底——而在线通道在国内网络下经常超时，
 * 于是出现「有时报错、再悬停又正常」的抖动。
 *
 * 策略：整词含连字符且各段都能在本地查到（含词形还原）时，拆开各段
 * 合成释义，彻底不走网络。任何一段查不到则返回 null（维持原在线兜底）。
 *
 * @param {function} lookupFn 传入 lookupLocal 以便递归复用（含还原逻辑）
 * @returns {Array|null} [{ part, hit }, ...] 或 null
 */
function lookupCompound(word, lookupFn) {
  const w = String(word).toLowerCase();
  // 每段 2 个以上字母、2~4 段；过短段落（如 e-mail 的 e）不拆，避免噪音
  if (!/^[a-z]{2,}(-[a-z]{2,}){1,3}$/.test(w)) return null;

  const parts = w.split("-");
  const hits = [];
  for (const p of parts) {
    const h = lookupFn(p);
    if (!h) return null; // 任一段未命中 → 整词放弃，走在线
    hits.push({ part: p, hit: h });
  }
  return hits;
}

/**
 * 规范化词组键：小写、去首尾空白、内部多空格压成单空格。
 *
 * 必须做这层规范化的原因：从 DOM 取到的文本可能含连续空格、换行、
 * 或 `&nbsp;` 转成的 \u00a0，直接查表会全部落空。
 *
 * @returns {string} 规范化后的词组键（可能为空串）
 */
function normalizePhrase(s) {
  return String(s == null ? "" : s)
    .replace(/[\u00a0\u2000-\u200b\u3000]/g, " ") // 各类不换行/全角空格
    .replace(/[\r\n\t]+/g, " ")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

/**
 * 词组查询（v1.3.0）。
 *
 * 词库分三份：精选单词 / 扩展单词 / 词组。词组键含空格，形状与单词互斥，
 * 但查询顺序上仍放在单词之后——因为单词查询更快且命中率更高，
 * 且「选中一个词」比「选中一个词组」更常见。
 *
 * 变体尝试顺序：
 *   1. 原样词组（"look forward to"）
 *   2. 去尾部标点（"look forward to." → "look forward to"）
 *   3. 去掉首尾冠词（"a bit of" → "bit of"，当用户多选了冠词）
 *
 * @param {string} rawPhrase 原始文本
 * @returns {object|null} 与 lookupLocal 同构：{ word, matched, entry, tier, phrase:true }
 */
function lookupPhrase(rawPhrase) {
  if (typeof DICT_PHRASE === "undefined" || !DICT_PHRASE) return null;

  let key = normalizePhrase(rawPhrase);
  if (!key || key.length < 3 || key.length > 60) return null;
  // 必须是「纯字母 + 单空格」，排除含数字/标点的文本
  if (!/^[a-z]+(?: [a-z]+)*$/.test(key)) {
    // 宽容处理：剥掉尾部标点后再试一次（"look forward to," 这类）
    key = key.replace(/[^a-z\s]+$/g, "").replace(/\s+/g, " ").trim();
    if (!/^[a-z]+(?: [a-z]+)*$/.test(key)) return null;
  }

  const tryKey = k => {
    const hit = lookupInDict(DICT_PHRASE, k);
    return hit ? { word: key, matched: k, entry: hit, tier: "phrase", phrase: true, inflected: false } : null;
  };

  let r = tryKey(key);
  if (r) return r;

  // 去掉首部冠词再试（用户可能多选了 "a" / "the"）
  const parts = key.split(" ");
  if (parts.length > 2 && (parts[0] === "a" || parts[0] === "the" || parts[0] === "an")) {
    r = tryKey(parts.slice(1).join(" "));
    if (r) return r;
  }
  return null;
}

/**
 * 依次尝试：原词 -> 各还原候选 -> 连字符拆词，返回首个命中的词条。
 *
 * 查询顺序：精选词库 dict.js 优先（释义更精炼、词性更准），
 * 未命中再查 ECDICT 扩展词库 dict-extra.js。
 * 这样精选词条的展示质量不会被机器生成的释义覆盖。
 *
 * @returns {object|null} { word, matched, entry, inflected? } 或 null
 */
function lookupLocal(rawWord) {
  // 两个词库都缺失时降级为纯在线模式，不让异常中断取词流程
  const hasMain = typeof LOCAL_DICT === "undefined" ? false : !!LOCAL_DICT;
  const hasExtra = typeof DICT_EXTRA === "undefined" ? false : !!DICT_EXTRA;
  const hasPhrase = typeof DICT_PHRASE === "undefined" ? false : !!DICT_PHRASE;
  if (!hasMain && !hasExtra && !hasPhrase) return null;

  const w = String(rawWord).toLowerCase();

  // 含空格 → 只可能是词组查询，直接走词组分支，省掉无谓的单词查表
  if (w.indexOf(" ") >= 0 || w.indexOf("\u00a0") >= 0) {
    return hasPhrase ? lookupPhrase(w) : null;
  }

  const dicts = [];
  if (hasMain) dicts.push({ name: "core", dict: LOCAL_DICT });
  if (hasExtra) dicts.push({ name: "extra", dict: DICT_EXTRA });

  // 按词库优先级依次查：先原词
  for (const d of dicts) {
    const hit = lookupInDict(d.dict, w);
    if (hit) return { word: w, matched: w, entry: hit, tier: d.name, inflected: false };
  }

  // 再查还原候选
  const cands = lemmatize(w);
  const list = typeof cands === "string" ? [cands] : (Array.isArray(cands) ? cands : []);

  for (const c of list) {
    if (!c || c === w) continue;
    for (const d of dicts) {
      const hit = lookupInDict(d.dict, c);
      if (hit) return { word: w, matched: c, entry: hit, tier: d.name, inflected: true };
    }
  }

  // 最后尝试连字符拆词（如 decision-maker -> decision + maker）
  const compound = lookupCompound(w, lookupLocal);
  if (compound) {
    return {
      word: w,
      matched: w,
      entry: null,          // 合成词无单一条目，buildLocalResult 按 compound 组装
      tier: compound[compound.length - 1].hit.tier,
      inflected: false,
      compound: compound
    };
  }
  return null;
}

/**
 * 把词条组装成气泡需要的数据结构（词性分组 + 音标 + 层级标记）。
 *
 * 放在共享模块里，是为了让 service worker 直接把"渲染就绪"的数据回给
 * 内容脚本——内容脚本不需要再懂词条结构，只需要会画。这样词条格式将来
 * 变化时只改一处。
 *
 * @param {object} local lookupLocal 的返回值
 * @returns {object} 可直接用于气泡渲染的结果对象
 */
function buildLocalResult(local) {
  // 合成词：每段一行（段名作词性位），释义取各段前 2 条
  if (local.compound) {
    const groups = [];
    for (const { part, hit } of local.compound) {
      const defs = String(hit.entry.t || "").split(/[；;]/).map(s => s.trim()).filter(Boolean);
      groups.push({ pos: part, text: defs.slice(0, 2).join("；") || "（无释义）" });
    }
    const firstPhon = local.compound.find(x => x.hit.entry.k);
    return {
      word: local.word,
      matched: local.matched,
      display: local.word,
      phonetic: (firstPhon && firstPhon.hit.entry.k) || "",
      inflected: false,
      groups: groups,
      plain: groups.map(g => g.text).join("；"),
      source: "local",
      tier: "compound"
    };
  }

  const entry = local.entry;
  const groups = [];
  const posList = String(entry.p || "").split("/").filter(Boolean);
  const defs = String(entry.t || "").split(/[；;]/).map(s => s.trim()).filter(Boolean);

  if (posList.length > 1 && defs.length > 1) {
    // 多词性：按词性数量均分释义（粗略映射，与词条生成规则一致）
    const per = Math.ceil(defs.length / posList.length);
    posList.forEach((p, i) => {
      const chunk = defs.slice(i * per, (i + 1) * per).join("；");
      if (chunk) groups.push({ pos: p, text: chunk });
    });
  } else {
    groups.push({ pos: posList[0] || "", text: defs.join("；") });
  }

  return {
    word: local.word,
    matched: local.matched,
    display: local.word,
    // 扩展词库带 k（音标）；精选词库与词组词库通常没有该字段
    phonetic: entry.k || "",
    inflected: !!local.inflected,
    groups: groups,
    plain: entry.t,
    source: "local",
    // 标记词条来源，气泡角标区分「精选词库 / 扩展词库 / 词组」
    tier: local.tier || (entry.k !== undefined ? "extra" : "core")
  };
}
